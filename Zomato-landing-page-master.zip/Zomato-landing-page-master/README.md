# Zomato Landing Page
This is a basic web development project build with HTML and CSS
